<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$ma_lop = $_GET['malop'] ?? '';
$id_edit = $_GET['id_edit'] ?? ''; 
$tab = $_GET['tab'] ?? 'bang-tin'; 

$ten_gv = $_SESSION['ho_ten'] ?? $_SESSION['hoten'] ?? $_SESSION['user_name'] ?? 'Giáo Viên';
$gv_avatar = '';
if (isset($_SESSION['user_id']) && isset($conn)) {
    $stmt_av = $conn->prepare("SELECT hoten, avatar FROM users WHERE id = ?");
    $stmt_av->bind_param("i", $_SESSION['user_id']);
    $stmt_av->execute();
    $row_av = $stmt_av->get_result()->fetch_assoc();
    if (!empty($row_av['hoten'])) $ten_gv = $row_av['hoten'];
    $gv_avatar = $row_av['avatar'] ?? '';
}
if (!empty($gv_avatar) && !str_starts_with($gv_avatar, 'http')) {
    $gv_avatar = '../uploads/' . $gv_avatar;
}
if (empty($gv_avatar)) {
    $gv_avatar = 'https://ui-avatars.com/api/?name=' . urlencode($ten_gv) . '&background=0288d1&color=fff&bold=true';
}
?>

<style>
    .bt-card { background: white; border-radius: 12px; padding: 25px; margin-bottom: 20px; border: 1px solid #edf2f5; position: relative; box-shadow: 0 4px 15px rgba(0,0,0,0.03); transition: all 0.3s ease; }
    .bt-card:hover { box-shadow: 0 6px 20px rgba(0,0,0,0.06); }
    .form-control { width: 100%; padding: 15px; border: 1px solid #cfd8dc; border-radius: 10px; outline: none; font-family: inherit; font-size: 15px; line-height: 1.5; transition: border-color 0.3s, box-shadow 0.3s; }
    .form-control:focus { border-color: #0288d1; box-shadow: 0 0 0 3px rgba(2, 136, 209, 0.1); background: #fff !important; }
    .actions-top { position: absolute; top: 20px; right: 20px; display: flex; gap: 12px; align-items: center; }
    .btn-edit { color: #0288d1; text-decoration: none; padding: 6px; border-radius: 6px; background: #e1f5fe; display: flex; align-items: center; transition: 0.2s; }
    .btn-edit:hover { background: #b3e5fc; transform: translateY(-2px); }
    .btn-delete-x { color: #ff5252; text-decoration: none; font-size: 20px; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; border-radius: 6px; background: #ffebee; transition: 0.2s; }
    .btn-delete-x:hover { background: #ffcdd2; transform: translateY(-2px); }
    .btn-upload-logo { display: inline-flex; align-items: center; justify-content: center; width: 45px; height: 45px; background: #f0f2f5; border-radius: 50%; cursor: pointer; transition: 0.3s; color: #546e7a; }
    .btn-upload-logo:hover { background: #e1f5fe; color: #0288d1; transform: scale(1.05); }
    .btn-primary { padding: 10px 25px; background: #0288d1; color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; transition: 0.2s; font-size: 14px; }
    .btn-primary:hover { background: #0277bd; transform: translateY(-1px); box-shadow: 0 4px 10px rgba(2, 136, 209, 0.2); }
    .btn-secondary { padding: 10px 20px; background: #f0f2f5; color: #546e7a; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; text-decoration: none; transition: 0.2s; font-size: 14px; }
    .btn-secondary:hover { background: #e4e8eb; color: #37474f; }
    .preview-files { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 15px; }
    .preview-tag { display: inline-flex; align-items: center; gap: 6px; background: #f1f8e9; color: #2e7d32; padding: 6px 12px; border-radius: 20px; font-size: 13px; border: 1px solid #c5e1a5; box-shadow: 0 2px 5px rgba(0,0,0,0.02); }
    .preview-tag.old-file { background: #e3f2fd; color: #0288d1; border-color: #bbdefb; }
    .remove-file-btn { color: #ff5252; font-weight: bold; cursor: pointer; text-decoration: none; padding-left: 6px; border-left: 1px solid rgba(0,0,0,0.1); margin-left: 4px; font-size: 16px; line-height: 1; }

    /* === BÌNH LUẬN === */
    .bl-section { margin-top: 18px; padding-top: 15px; border-top: 1px solid #edf2f5; }
    .bl-title { font-size: 13px; font-weight: 700; color: #78909c; margin-bottom: 12px; }
    .bl-item { display: flex; gap: 10px; margin-bottom: 12px; align-items: flex-start; }
    .bl-avatar { width: 34px; height: 34px; border-radius: 50%; background: #e1f5fe; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 13px; color: #0277bd; flex-shrink: 0; overflow: hidden; }
    .bl-avatar img { width: 100%; height: 100%; object-fit: cover; }
    .bl-bubble { background: #f4f6f8; border-radius: 12px; padding: 10px 14px; flex: 1; }
    .bl-name { font-size: 13px; font-weight: 800; color: #263238; margin-bottom: 3px; }
    .bl-text { font-size: 14px; color: #37474f; line-height: 1.5; }
    .bl-time { font-size: 11px; color: #b0bec5; margin-top: 4px; }
    .bl-form { display: flex; gap: 10px; margin-top: 12px; align-items: center; }
    .bl-input { flex: 1; padding: 10px 14px; border: 1px solid #e0e0e0; border-radius: 20px; font-family: inherit; font-size: 14px; outline: none; transition: border-color 0.2s; background: #f9fafb; }
    .bl-input:focus { border-color: #0288d1; background: white; }
    .bl-send-btn { width: 38px; height: 38px; border-radius: 50%; background: #0288d1; border: none; color: white; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: 0.2s; flex-shrink: 0; }
    .bl-send-btn:hover { background: #0277bd; transform: scale(1.05); }
    .empty-state { text-align: center; padding: 40px 20px; color: #90a4ae; font-size: 15px; background: #fafbfc; border-radius: 12px; border: 1px dashed #cfd8dc; }
    
    /* Chỉ thêm phần này cho "đã chỉnh sửa" */
    .edited-text { 
        font-size: 12px; 
        color: #0288d1; 
        font-style: italic; 
        margin-left: 8px; 
        font-weight: 600; 
    }
</style>

<div class="bt-card" style="padding: 20px;">
    <form action="xulybangtin.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="add_post">
        <input type="hidden" name="ma_lop" value="<?= htmlspecialchars($ma_lop) ?>">
        
        <textarea name="noi_dung" class="form-control" style="min-height: 80px; resize: none; background: #f9fbfb; overflow: hidden;" placeholder="Thông báo nội dung gì đó cho lớp học..." required oninput="this.style.height = ''; this.style.height = this.scrollHeight + 'px'"></textarea>
        
        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 15px;">
            <label class="btn-upload-logo" title="Đính kèm tài liệu">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path></svg>
                <input type="file" name="post_files[]" id="post_input_add" multiple style="display: none;" onchange="updatePostPreview('post_input_add', 'preview-post-add')">
            </label>
            <button type="submit" class="btn-primary">Đăng thông báo</button>
        </div>
        <div id="preview-post-add" class="preview-files"></div>
    </form>
</div>

<div id="post-list">
    <?php 
    $ds_post = [];
    if (isset($conn)) {
        $stmt = $conn->prepare("SELECT b.* FROM bang_tin b INNER JOIN classes c ON b.class_id = c.id WHERE c.ma_lop = ? ORDER BY b.id DESC");
        $stmt->bind_param("s", $ma_lop);
        $stmt->execute();
        $result = $stmt->get_result();
        while($row = $result->fetch_assoc()) {
            $row['files'] = !empty($row['file_dinh_kem']) ? explode(',', $row['file_dinh_kem']) : [];
            $row['ngay_dang'] = date('H:i d/m/Y', strtotime($row['ngay_tao']));
            $ds_post[] = $row;
        }
    }
    
    $has_posts = false;

    foreach ($ds_post as $post): 
        $has_posts = true;
        if ($post['id'] == $id_edit): 
    ?>
                <div class="bt-card" id="post-<?= $post['id'] ?>" style="border: 2px solid #0288d1; background: #f2fbff;">
                    <div style="font-weight: bold; color: #0288d1; margin-bottom: 15px; font-size: 16px; display: flex; align-items: center; gap: 8px;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                        Đang chỉnh sửa thông báo
                    </div>
                    
                    <form action="xulybangtin.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="update_post">
                        <input type="hidden" name="id_update" value="<?= $post['id'] ?>">
                        <input type="hidden" name="ma_lop" value="<?= htmlspecialchars($ma_lop) ?>">
                        
                        <textarea name="noi_dung" class="form-control" style="min-height: 100px; resize: none; overflow: hidden;" placeholder="Nội dung thông báo..." required oninput="this.style.height = ''; this.style.height = this.scrollHeight + 'px'"><?= htmlspecialchars($post['noi_dung']) ?></textarea>
                        
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 15px;">
                            <label class="btn-upload-logo" title="Thêm file mới">
                                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path></svg>
                                <input type="file" name="post_files[]" id="post_input_<?= $post['id'] ?>" multiple style="display: none;" onchange="updatePostPreview('post_input_<?= $post['id'] ?>', 'preview-post-<?= $post['id'] ?>')">
                            </label>
                            
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <a href="phonghoc.php?malop=<?= $ma_lop ?>&tab=<?= $tab ?>#post-<?= $post['id'] ?>" class="btn-secondary">Hủy</a>
                                <button type="submit" class="btn-primary">Lưu thay đổi</button>
                            </div>
                        </div>

                        <div id="preview-post-<?= $post['id'] ?>" class="preview-files">
                            <?php if(!empty($post['files'])): ?>
                                <?php foreach($post['files'] as $f): $file_id = md5($f); ?>
                                    <span class="preview-tag old-file" id="file-<?= $file_id ?>">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
                                        <?= (strlen($f) > 20) ? substr($f, 0, 15).'...' : $f ?>
                                        <input type="hidden" name="old_files[]" value="<?= htmlspecialchars($f) ?>">
                                        <a onclick="document.getElementById('file-<?= $file_id ?>').remove()" class="remove-file-btn" title="Xóa file này">&times;</a>
                                    </span>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>

    <?php 
        else: 
    ?>
                <div class="bt-card" id="post-<?= $post['id'] ?>">
                    <div class="actions-top">
                        <a href="?malop=<?= $ma_lop ?>&tab=<?= $tab ?>&id_edit=<?= $post['id'] ?>#post-<?= $post['id'] ?>" class="btn-edit" title="Sửa thông báo">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                        </a>
                        <a href="xulybangtin.php?action=delete_post&id=<?= $post['id'] ?>&malop=<?= $ma_lop ?>" class="btn-delete-x" onclick="return confirm('Bạn có chắc chắn muốn xóa thông báo này?')" title="Xóa thông báo">&times;</a>
                    </div>

                    <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px;">
                        <img src="<?= htmlspecialchars($gv_avatar) ?>" alt="Avatar" style="width: 45px; height: 45px; border-radius: 50%; object-fit: cover; box-shadow: 0 2px 5px rgba(2, 136, 209, 0.3); border: 2px solid #0288d1;">
                        <div>
                            <div style="font-weight: 700; color: #263238; font-size: 15px;"><?= htmlspecialchars($ten_gv) ?></div>
                            <div style="font-size: 12px; color: #78909c; margin-top: 2px;">
                                <?= $post['ngay_dang'] ?>
                                <?php if (!empty($post['chinh_sua']) && $post['chinh_sua'] == 1): ?>
                                    <span class="edited-text">• đã chỉnh sửa</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <p style="font-size: 15px; line-height: 1.7; color: #37474f; margin: 15px 0; padding-right: 50px; white-space: pre-wrap;"><?= htmlspecialchars($post['noi_dung']) ?></p>

                    <?php if(!empty($post['files'])): ?>
                        <div style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 20px; padding-top: 15px; border-top: 1px solid #f0f2f5;">
                            <?php foreach($post['files'] as $f): ?>
                                <a href="../uploads/<?= htmlspecialchars($f) ?>" target="_blank" style="text-decoration: none; background: #f4f6f8; padding: 8px 16px; border-radius: 8px; border: 1px solid #e4e8eb; font-size: 13px; color: #0277bd; font-weight: 600; display: flex; align-items: center; gap: 8px; transition: 0.2s;">
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
                                    <?= (strlen($f) > 25) ? substr($f, 0, 22).'...' : htmlspecialchars($f) ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <!-- BÌNH LUẬN -->
                    <div class="bl-section">
                        <?php
                        // Lấy bình luận của bài đăng này
                        $stmt_bl = $conn->prepare("
                            SELECT bl.*, u.hoten, u.avatar, u.role
                            FROM binh_luan bl
                            JOIN users u ON u.id = bl.id_user
                            WHERE bl.id_bangtin = ?
                            ORDER BY bl.ngay_tao ASC
                        ");
                        $stmt_bl->bind_param("i", $post['id']);
                        $stmt_bl->execute();
                        $bls = $stmt_bl->get_result();
                        $bl_count = $bls->num_rows;
                        ?>
                        <?php if ($bl_count > 0): ?>
                            <div class="bl-title">💬 <?= $bl_count ?> bình luận</div>
                            <?php while ($bl = $bls->fetch_assoc()):
                                $bl_av = !empty($bl['avatar']) ? '../uploads/' . ltrim($bl['avatar'], '/') : '';
                                $bl_name_char = mb_substr($bl['hoten'], 0, 1, 'UTF-8');
                                $is_teacher = ($bl['role'] === 'teacher');
                            ?>
                            <div class="bl-item">
                                <div class="bl-avatar">
                                    <?php if ($bl_av): ?>
                                        <img src="<?= htmlspecialchars($bl_av) ?>" 
                                             onerror="this.parentNode.textContent='<?= $bl_name_char ?>'">
                                    <?php else: ?>
                                        <?= htmlspecialchars($bl_name_char) ?>
                                    <?php endif; ?>
                                </div>
                                <div class="bl-bubble" <?= $is_teacher ? 'style="background:#e3f2fd;border-left:3px solid #0288d1;"' : '' ?>>
                                    <div class="bl-name">
                                        <?= htmlspecialchars($bl['hoten']) ?>
                                        <?php if ($is_teacher): ?>
                                            <span style="font-size:11px;background:#0288d1;color:white;padding:2px 6px;border-radius:10px;margin-left:4px;">GV</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="bl-text"><?= nl2br(htmlspecialchars($bl['noi_dung'])) ?></div>
                                    <div class="bl-time"><?= date('H:i d/m/Y', strtotime($bl['ngay_tao'])) ?></div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="bl-title" style="color:#cfd8dc;">💬 Chưa có bình luận nào</div>
                        <?php endif; ?>

                        <!-- Form GV bình luận -->
                        <form action="xulybinhluan_gv.php" method="POST" class="bl-form">
                            <input type="hidden" name="id_bangtin" value="<?= $post['id'] ?>">
                            <input type="hidden" name="ma_lop" value="<?= htmlspecialchars($ma_lop) ?>">
                            <input type="text" name="noi_dung_bl" class="bl-input" 
                                   placeholder="Giáo viên nhận xét, trả lời...">
                            <button type="submit" class="bl-send-btn" title="Gửi">
                                <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                            </button>
                        </form>
                    </div>
                </div>
    <?php 
        endif; 
    endforeach; 

    if (!$has_posts):
    ?>
        <div class="empty-state">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#cfd8dc" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="margin-bottom: 10px;"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
            <br>Lớp học chưa có thông báo nào.
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const textareas = document.querySelectorAll('textarea');
    textareas.forEach(ta => {
        if(ta.value.trim() !== '') {
            ta.style.height = ta.scrollHeight + 'px';
        }
    });
});

function updatePostPreview(inputId, previewId) {
    const input = document.getElementById(inputId);
    const preview = document.getElementById(previewId);
    
    const newTags = preview.querySelectorAll('.preview-tag.new-file');
    newTags.forEach(tag => tag.remove());

    Array.from(input.files).forEach((file, index) => {
        const tag = document.createElement('span');
        tag.className = 'preview-tag new-file';
        tag.innerHTML = `
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>
            ${(file.name.length > 15) ? file.name.substring(0, 12) + '...' : file.name} (Mới)
            <a onclick="removePostNewFile('${inputId}', '${previewId}', ${index})" class="remove-file-btn" title="Hủy chọn">&times;</a>
        `;
        preview.appendChild(tag);
    });
}

function removePostNewFile(inputId, previewId, indexToRemove) {
    const input = document.getElementById(inputId);
    const dt = new DataTransfer(); 
    const { files } = input;
    
    for (let i = 0; i < files.length; i++) {
        if (i !== indexToRemove) {
            dt.items.add(files[i]); 
        }
    } 
    input.files = dt.files; 
    updatePostPreview(inputId, previewId); 
}
</script>