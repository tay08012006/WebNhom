<?php include("config.php"); ?>

<style>
    .nav-bar {
        background-color: #2c3e50;
        padding: 15px 20px;
        display: flex;
        align-items: center;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    .nav-bar a {
        color: white;
        text-decoration: none;
        padding: 10px 15px;
        margin-right: 10px;
        border-radius: 4px;
        transition: background 0.3s ease;
        font-family: Arial, sans-serif;
    }
    .nav-bar a:hover {
        background-color: #34495e;
    }
    .nav-bar .logout-btn {
        margin-left: auto;
        background-color: #e74c3c;
    }
    .nav-bar .logout-btn:hover {
        background-color: #c0392b;
    }
</style>
<nav class="nav-bar">
    <a href="logout.php" class="logout-btn">Thoát</a>
</nav>

<hr style="margin: 20px 0; border: 0; border-top: 1px solid #ddd;">