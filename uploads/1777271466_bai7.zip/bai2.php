<?php include("config.php"); ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Kết quả học tập</title>
<style>
body {
    font-family: Arial;
    background: #f5f5f5;
}
.container {
    width: 400px;
    margin: 50px auto;
    background: white;
    padding: 20px;
    border-radius: 10px;
    border: 1px solid #ddd;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}
h2 {
    text-align: center;
    background: #32a6e9;
    color: white;
    padding: 10px;
    border-radius: 5px;
    margin-top: 0;
}
input {
    width: 100%;
    padding: 5px;
    margin: 5px 0;
}
.result {
    background: #fff3cd;
}
button {
    margin-top: 10px;
    padding: 10px;
    width: 100%;
    background: #6c757d;
    color: white;
    border: none;
    border-radius: 5px;
}
</style>
</head>
<body>
<div class="container">
<h2>KẾT QUẢ HỌC TẬP</h2>
<form method="post">
    Điểm HK1:
    <input type="text" name="hk1"><br>
    Điểm HK2:
    <input type="text" name="hk2"><br>
    <button type="submit" name="tinh">Xem kết quả</button>
</form>
<?php
if(isset($_POST['tinh'])){
    $hk1 = $_POST['hk1'];
    $hk2 = $_POST['hk2'];
    if(is_numeric($hk1) && is_numeric($hk2)){
        $dtb = ($hk1 + $hk2) / 2;
        $dtb = round($dtb, 2); // làm tròn

        if($dtb >= 9){
            $xeploai = "Xuất Sắc";
        } elseif($dtb >= 8){
            $xeploai = "Giỏi";
        } elseif($dtb >= 6.5){
            $xeploai = "Khá";
        } elseif($dtb >= 5){
            $xeploai = "Trung Bình";
        } else {
            $xeploai = "Yếu";
        }
        $ketqua = ($dtb >= 5) ? "Được lên lớp" : "Ở lại lớp";
        echo "Điểm trung bình:
        <input class='result' value='$dtb' readonly><br>";
        echo "Kết quả:
        <input class='result' value='$ketqua' readonly><br>";
        echo "Xếp loại:
        <input class='result' value='$xeploai' readonly><br>";
    } else {
        echo "<p style='color:red'>Vui lòng nhập số hợp lệ!</p>";
    }
}
?>
<br>
<a href="index.php">Quay lại menu</a>
</div>
</body>
</html>