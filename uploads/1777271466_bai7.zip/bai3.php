<?php include("config.php"); ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Kết quả thi</title>
<style>
body {
    font-family: Arial;
    background: #f5f5f5;
}
.container {
    width: 400px;
    margin: 50px auto;
    background: white;
    padding: 20px;
    border-radius: 10px;
    border: 1px solid #ddd;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}
h2 {
    text-align: center;
    background: #32a6e9;
    color: white;
    padding: 10px;
    border-radius: 5px;
}
input {
    width: 100%;
    padding: 5px;
    margin: 5px 0;
}
.result {
    background: #fff3cd;
}
button {
    margin-top: 10px;
    padding: 8px;
    width: 100%;
    background: #6c757d;
    color: white;
    border: none;
}
</style>
</head>
<body>
<div class="container">
<h2>KẾT QUẢ THI ĐẠI HỌC</h2>
<form method="post">
    Toán:
    <input type="text" name="toan"><br>
    Lý:
    <input type="text" name="ly"><br>
    Hóa:
    <input type="text" name="hoa"><br>
    Điểm chuẩn:
    <input type="text" name="dc"><br>
    <button type="submit" name="tinh">Xem kết quả</button>
</form>
<?php
if(isset($_POST['tinh'])){
    $toan = $_POST['toan'];
    $ly = $_POST['ly'];
    $hoa = $_POST['hoa'];
    $dc = $_POST['dc'];
    if(is_numeric($toan) && is_numeric($ly) && is_numeric($hoa) && is_numeric($dc)){
        if($toan == 0 || $ly == 0 || $hoa == 0){
            $ketqua = "Rớt (có điểm liệt)";
            $tong = $toan + $ly + $hoa;
        } else {
            $tong = $toan + $ly + $hoa;
            $tong = round($tong, 2);
            $ketqua = ($tong >= $dc) ? "Đậu" : "Rớt";
        }
        echo "Tổng điểm:
        <input class='result' value='$tong' readonly><br>";

        echo "Kết quả thi:
        <input class='result' value='$ketqua' readonly><br>";

    } else {
        echo "<p style='color:red'>Vui lòng nhập số hợp lệ!</p>";
    }
}
?>
<br>
<a href="index.php">Quay lại menu</a>
</div>
</body>
</html>