<?php 
include("config.php"); 
$tong = "";
$bd = isset($_POST['bd']) ? $_POST['bd'] : "";
$kt = isset($_POST['kt']) ? $_POST['kt'] : "";
$error = "";
if(isset($_POST['tinh'])){
    if(is_numeric($bd) && is_numeric($kt)){
        $bd = (float)$bd;
        $kt = (float)$kt;
        if($bd >= 10 && $kt <= 24 && $kt > $bd){
            $sotien = 0;
            for($i = $bd; $i < $kt; $i++){
                if($i < 17){
                    $sotien += 45000;
                } else {
                    $sotien += 60000;
                }
            }
            $tong = number_format($sotien);
        } else {
            if ($bd < 10 || $kt > 24) {
                $error = "Karaoke chỉ mở cửa từ 10h - 24h!";
            } else {
                $error = "Giờ kết thúc phải lớn hơn giờ bắt đầu!";
            }
        }
    } else {
        $error = "Vui lòng nhập số giờ hợp lệ!";
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Tính Tiền Karaoke</title>
    <style>
        :root {
            --bg-karaoke: #008b8b;
            --header-bg: #007373;
            --text-color: #ffffff;
        }
        body {
            background: #f4f4f4;
            font-family: 'Segoe UI', Arial, sans-serif;
            display: flex;
            justify-content: center;
            padding-top: 50px;
        }
        .box {
            width: 420px;
            background: var(--bg-karaoke);
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            overflow: hidden;
            color: var(--text-color);
        }
        .header {
            background: var(--header-bg);
            text-align: center;
            padding: 15px;
            font-size: 1.4rem;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        form {
            padding: 25px;
        }
        .input-group {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        .input-group label {
            width: 130px;
            font-weight: 500;
        }
        .input-wrapper {
            flex: 1;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        input[type="text"] {
            width: 100%;
            padding: 8px;
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 4px;
            outline: none;
            font-size: 1rem;
        }
        .result {
            background: #dfffdf !important;
            color: #111 !important;
            font-weight: bold;
            border: none !important;
        }
        .btn-container {
            text-align: center;
            margin-top: 20px;
        }
        button {
            padding: 10px 30px;
            background: #e1e1e1;
            border: 1px solid #888;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            color: #333;
            transition: 0.3s;
        }
        button:hover {
            background: #ffffff;
            box-shadow: 0 0 10px rgba(255,255,255,0.4);
        }
        .error {
            background: #ffcccc;
            color: #b30000;
            padding: 10px;
            text-align: center;
            margin: 0 25px 15px 25px;
            border-radius: 4px;
            font-size: 0.85rem;
            font-weight: bold;
        }
        .back-link {
            display: block;
            text-align: center;
            padding: 15px;
            color: #e0f7fa;
            text-decoration: none;
            font-size: 0.9rem;
        }
        .back-link:hover { text-decoration: underline; }
    </style>
</head>
<body>
<div class="box">
    <div class="header">Tính Tiền Karaoke</div>
    <form method="post">
        <div class="input-group">
            <label>Giờ bắt đầu:</label>
            <div class="input-wrapper">
                <input type="text" name="bd" value="<?php echo htmlspecialchars($bd); ?>" placeholder="10 - 24">
                <span>(h)</span>
            </div>
        </div>
        <div class="input-group">
            <label>Giờ kết thúc:</label>
            <div class="input-wrapper">
                <input type="text" name="kt" value="<?php echo htmlspecialchars($kt); ?>" placeholder="10 - 24">
                <span>(h)</span>
            </div>
        </div>
        <div class="input-group">
            <label>Tiền thanh toán:</label>
            <div class="input-wrapper">
                <input class="result" type="text" value="<?php echo $tong; ?>" readonly>
                <span>(VNĐ)</span>
            </div>
        </div>
        <?php if($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        <div class="btn-container">
            <button type="submit" name="tinh">Tính tiền</button>
        </div>
    </form>
    <a href="index.php" class="back-link">Quay lại menu chính</a>
</div>
</body>
</html>