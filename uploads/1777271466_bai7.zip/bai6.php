<?php 
include("config.php");
$nt = isset($_POST['nt']) ? $_POST['nt'] : ""; 
$tg = ""; 
$vnd = "";
$sl = isset($_POST['sl']) ? $_POST['sl'] : ""; 
$dg = ""; 
$vang = "";
$loai_nt = isset($_POST['loai_nt']) ? $_POST['loai_nt'] : "aud"; 
$loai_vang = isset($_POST['loai_vang']) ? $_POST['loai_vang'] : "sjc";
$error = "";
if(isset($_POST['tinh'])){
    // ===== ĐỔI NGOẠI TỆ =====
    if($loai_nt == "usd") $tg = 24000;
    else if($loai_nt == "aud") $tg = 14057;
    else if($loai_nt == "eur") $tg = 26000;
    if(is_numeric($nt)){
        $vnd = number_format($nt * $tg);
    } else if (!empty($nt)) {
        $error = "Số tiền ngoại tệ phải là số!";
    }
    // ===== MUA VÀNG =====
    if($loai_vang == "sjc") $dg = 1305000;
    else if($loai_vang == "aaa") $dg = 1200000;
    else if($loai_vang == "pnj") $dg = 1250000;
    if(is_numeric($sl)){
        $vang = number_format($sl * $dg);
    } else if (!empty($sl)) {
        $error = "Số lượng vàng phải là số!";
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chuyển Đổi Ngoại Tệ & Vàng</title>
    <style>
        :root {
            --primary-color: #f39c12;
            --accent-color: #e67e22;
            --bg-body: #f0f2f5;
            --text-dark: #2c3e50;
            --white: #ffffff;
        }
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: var(--bg-body);
            color: var(--text-dark);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        .container {
            width: 100%;
            max-width: 850px;
            background: var(--white);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
            margin: 20px;
        }
        .header-title {
            background: var(--primary-color);
            color: white;
            text-align: center;
            padding: 20px;
            font-size: 1.5rem;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .main-form {
            padding: 30px;
        }
        .grid-layout {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }
        @media (max-width: 768px) {
            .grid-layout { grid-template-columns: 1fr; }
        }
        .section-box {
            background: #fafafa;
            border: 1px solid #eee;
            padding: 20px;
            border-radius: 10px;
        }
        .section-box h3 {
            margin-top: 0;
            color: var(--accent-color);
            border-bottom: 2px solid var(--primary-color);
            display: inline-block;
            margin-bottom: 20px;
            font-size: 1.1rem;
        }
        .input-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            font-size: 0.9rem;
        }
        input[type="text"], select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 6px;
            box-sizing: border-box;
            transition: 0.3s;
        }
        input:focus, select:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 5px rgba(243, 156, 18, 0.3);
        }
        .readonly-field {
            background-color: #fdf2e9;
            color: #d35400;
            font-weight: bold;
            border-color: #f5c091 !important;
        }
        .radio-group {
            display: flex;
            gap: 15px;
            padding: 5px 0;
        }
        .radio-item {
            display: flex;
            align-items: center;
            gap: 5px;
            cursor: pointer;
        }
        .btn-container {
            text-align: center;
            margin-top: 30px;
        }
        button {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 12px 40px;
            font-size: 1rem;
            font-weight: bold;
            border-radius: 50px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(243, 156, 18, 0.3);
        }
        button:hover {
            background: var(--accent-color);
            transform: translateY(-2px);
        }
        .error-msg {
            color: #e74c3c;
            text-align: center;
            margin-top: 15px;
            font-weight: bold;
        }
        .footer-link {
            display: block;
            text-align: center;
            padding: 20px;
            text-decoration: none;
            color: #7f8c8d;
            font-size: 0.9rem;
        }
        .footer-link:hover { color: var(--accent-color); }
    </style>
</head>
<body>
<div class="container">
    <div class="header-title">Đổi Ngoại Tệ - Vàng</div>   
    <form method="post" class="main-form">
        <div class="grid-layout">
            <div class="section-box">
                <h3>ĐỔI NGOẠI TỆ</h3>
                <div class="input-group">
                    <label>Số tiền:</label>
                    <input type="text" name="nt" value="<?php echo htmlspecialchars($nt); ?>" placeholder="Nhập số tiền...">
                </div>
                <div class="input-group">
                    <label>Loại ngoại tệ:</label>
                    <select name="loai_nt">
                        <option value="usd" <?php if($loai_nt=="usd") echo "selected"; ?>>USD (Đô Mỹ)</option>
                        <option value="aud" <?php if($loai_nt=="aud") echo "selected"; ?>>AUD (Đô Úc)</option>
                        <option value="eur" <?php if($loai_nt=="eur") echo "selected"; ?>>EUR (Euro)</option>
                    </select>
                </div>
                <div class="input-group">
                    <label>Tỷ giá (VND):</label>
                    <input class="readonly-field" value="<?php echo number_format((float)$tg); ?>" readonly>
                </div>
                <div class="input-group">
                    <label>Thành tiền VND:</label>
                    <input class="readonly-field" value="<?php echo $vnd; ?>" readonly>
                </div>
            </div>
            <div class="section-box">
                <h3>MUA VÀNG</h3>
                <div class="input-group">
                    <label>Số lượng:</label>
                    <input type="text" name="sl" value="<?php echo htmlspecialchars($sl); ?>" placeholder="Nhập số lượng...">
                </div>
                <div class="input-group">
                    <label>Loại vàng:</label>
                    <div class="radio-group">
                        <label class="radio-item">
                            <input type="radio" name="loai_vang" value="sjc" <?php if($loai_vang=="sjc") echo "checked"; ?>> SJC
                        </label>
                        <label class="radio-item">
                            <input type="radio" name="loai_vang" value="aaa" <?php if($loai_vang=="aaa") echo "checked"; ?>> AAA
                        </label>
                        <label class="radio-item">
                            <input type="radio" name="loai_vang" value="pnj" <?php if($loai_vang=="pnj") echo "checked"; ?>> PNJ
                        </label>
                    </div>
                </div>
                <div class="input-group">
                    <label>Đơn giá:</label>
                    <input class="readonly-field" value="<?php echo number_format((float)$dg); ?>" readonly>
                </div>
                <div class="input-group">
                    <label>Thành tiền VND:</label>
                    <input class="readonly-field" value="<?php echo $vang; ?>" readonly>
                </div>
            </div>
        </div>
        <?php if($error): ?>
            <div class="error-msg"><?php echo $error; ?></div>
        <?php endif; ?>
        <div class="btn-container">
            <button type="submit" name="tinh">Tính toán quy đổi</button>
        </div>
    </form>
    <a href="index.php" class="footer-link">Quay lại menu</a>
</div>
</body>
</html>