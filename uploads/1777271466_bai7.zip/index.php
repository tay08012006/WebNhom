<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Bài 7</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 800px;
            margin: 30px auto;
            padding: 20px;
            background-color: white;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .welcome {
            background-color: #32a6e9;
            color: white;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .welcome h1 {
            margin: 0;
        }
        .menu-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-top: 20px;
        }
        .menu-item {
            background-color: #e3f2fd;
            padding: 15px;
            border-left: 4px solid #1976d2;
            border-radius: 3px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s ease;
            text-align: center;
            font-weight: bold;
        }
        .menu-item:hover {
            background-color: #bbdefb;
            transform: translateX(5px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <div class="container">
        <div class="welcome">
            <p>Đây là Bài 7 - Trang web tổng hợp các bài tập từ Bài 1 đến Bài 6</p>
        </div>
        <h2>Các bài tập có sẵn:</h2>
        <div class="menu-grid">
            <a href="bai1.php" class="menu-item">
                Bài 1<br>Chương trình Đăng nhập
            </a>
            <a href="bai2.php" class="menu-item">
                Bài 2<br>Kết quả Học tập
            </a>
            <a href="bai3.php" class="menu-item">
                Bài 3<br>Kết quả Thi Đại học
            </a>
            <a href="bai4.php" class="menu-item">
                Bài 4<br>Diện tích Hình chữ nhật
            </a>
            <a href="bai5.php" class="menu-item">
                Bài 5<br>Tính tiền Karaoke
            </a>
            <a href="bai6.php" class="menu-item">
                Bài 6<br>Đổi Ngoại tệ & Vàng
            </a>
        </div>
    </div>
</body>
</html>
