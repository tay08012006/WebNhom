<?php 
include("config.php"); 
$dt = "";
$dai = isset($_POST['dai']) ? $_POST['dai'] : "";
$rong = isset($_POST['rong']) ? $_POST['rong'] : "";
$error = "";
if(isset($_POST['tinh'])){
    if(is_numeric($dai) && is_numeric($rong)){
        if($dai > 0 && $rong > 0) {
            $dt = $dai * $rong;
        } else {
            $error = "Chiều dài và rộng phải lớn hơn 0!";
        }
    } else {
        $error = "Vui lòng nhập số hợp lệ!";
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Diện Tích Hình Chữ Nhật</title>
    <style>
        :root {
            --primary-bg: #ffffff;
            --header-bg: #f4b942;
            --text-color: #7a4a05;
        }
        body {
            background: #ffffff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            padding-top: 50px;
        }
        .box {
            width: 450px;
            background: var(--primary-bg);
            border: 1px solid #eecb8d;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            border-radius: 4px;
            overflow: hidden;
        }
        .header {
            background: var(--header-bg);
            color: var(--text-color);
            text-align: center;
            padding: 15px;
            font-size: 1.6rem;
            font-weight: bold;
            font-family: 'Times New Roman', serif; 
            font-style: italic;
        }
        form {
            padding: 20px 30px;
        }
        .row {
            display: flex;
            align-items: center;
            margin-bottom: 12px;
        }
        .row label {
            width: 120px;
            font-weight: bold;
            color: #555;
        }
        input[type="text"] {
            flex: 1;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
            outline: none;
        }
        input:focus {
            border-color: var(--header-bg);
        }
        .result {
            background: #fbc7d4 !important;
            border: 1px solid #f8a5bb !important;
            font-weight: bold;
            color: #333;
        }
        .btn-container {
            text-align: center;
            margin-top: 15px;
        }
        button {
            padding: 8px 25px;
            background: #e1e1e1;
            border: 1px solid #999;
            cursor: pointer;
            font-weight: bold;
            transition: 0.2s;
        }
        button:hover {
            background: #d4d4d4;
        }
        .error {
            color: red;
            font-size: 0.9rem;
            text-align: center;
            margin-bottom: 10px;
        }
        .menu-link {
            display: block;
            text-align: center;
            margin-bottom: 20px;
            color: #0066cc;
            text-decoration: none;
        }
    </style>
</head>
<body>
<div class="box">
    <div class="header">DIỆN TÍCH HÌNH CHỮ NHẬT</div>
    <form method="post">
        <?php if($error) echo "<div class='error'>$error</div>"; ?>
        <div class="row">
            <label>Chiều dài:</label>
            <input type="text" name="dai" value="<?php echo htmlspecialchars($dai); ?>">
        </div>
        <div class="row">
            <label>Chiều rộng:</label>
            <input type="text" name="rong" value="<?php echo htmlspecialchars($rong); ?>">
        </div>
        <div class="row">
            <label>Diện tích:</label>
            <input class="result" type="text" value="<?php echo $dt; ?>" readonly>
        </div>
        <div class="btn-container">
            <button name="tinh">Tính</button>
        </div>
    </form>
    <a href="index.php" class="menu-link">Quay lại menu</a>
</div>
</body>
</html>